

document.addEventListener('DOMContentLoaded',function() {
  //read only pointer to local storage
  var myStorage = window.localStorage;
  //gets the key (which is the timeline (60 min) from local storage)
  var check = myStorage.getItem('key');
  //checks the url
  var url = window.location.href;
  //creates date which is the current time
  var date = new Date().getMinutes
  //if the current time is before the deadline OR the url contains a string that would note that it's already been redirected once
  if (date < check  || url.includes("magicstring")){
    //looks in local storage, sets the key to the current date + 1 hour which says when the user starts being redirected again
    myStorage.setItem("key",date + 60); 
    //facebook is redirected
  } else {
    window.location.href = "http://procrastination-station.com"
  }
}, false);
